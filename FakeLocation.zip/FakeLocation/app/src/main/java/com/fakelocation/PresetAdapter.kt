package com.fakelocation

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class Preset(val name: String, val lat: Double, val lng: Double)

class PresetAdapter(
    private val items: List<Preset>,
    private val onClick: (Preset) -> Unit
) : RecyclerView.Adapter<PresetAdapter.VH>() {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvName: TextView = view.findViewById(R.id.tvPresetName)
        val tvCoords: TextView = view.findViewById(R.id.tvPresetCoords)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_preset, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val preset = items[position]
        holder.tvName.text = preset.name
        holder.tvCoords.text = "%.4f, %.4f".format(preset.lat, preset.lng)
        holder.itemView.setOnClickListener { onClick(preset) }
    }

    override fun getItemCount() = items.size
}
