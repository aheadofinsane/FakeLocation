package com.fakelocation

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.fakelocation.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var s: AppSettings

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.apply { title = "Settings"; setDisplayHomeAsUpEnabled(true) }
        s = AppSettings(this)
        populate()
        attachListeners()
        updateAdvancedJitterVisibility(s.advancedJitter)
        updateStaticJitterVisibility(s.jitterStatic)
        updateSeparateJitterVisibility(s.jitterSeparate)
    }

    // ── Populate all views from current settings ──────────────────────────────

    private fun populate() = with(binding) {
        // Providers
        switchSpoofGps.isChecked     = s.spoofGps
        switchSpoofNetwork.isChecked = s.spoofNetwork
        switchSpoofPassive.isChecked = s.spoofPassive
        switchSpoofBle.isChecked     = s.spoofBle

        // Basic jitter
        switchJitter.isChecked   = s.jitter
        etJitterMax.setText(s.jitterMaxMetres.toString())

        // Advanced jitter master toggle
        switchAdvancedJitter.isChecked = s.advancedJitter

        // Static
        switchJitterStatic.isChecked   = s.jitterStatic
        etStaticLat.setText(s.jitterStaticLat.toString())
        etStaticLng.setText(s.jitterStaticLng.toString())

        // Separate axes
        switchJitterSeparate.isChecked  = s.jitterSeparate
        etJitterMaxLat.setText(s.jitterMaxLat.toString())
        etJitterMaxLng.setText(s.jitterMaxLng.toString())

        // Positive-only
        switchPosOnlyLat.isChecked = s.jitterPositiveOnlyLat
        switchPosOnlyLng.isChecked = s.jitterPositiveOnlyLng

        // Per-provider
        switchJitterGps.isChecked     = s.jitterOnGps
        switchJitterNetwork.isChecked = s.jitterOnNetwork
        switchJitterPassive.isChecked = s.jitterOnPassive

        // Nudge
        etNudgeStep.setText(s.nudgeStep.toString())

        // Drift
        etDriftLat.setText(s.driftLatMicro.toString())
        etDriftLng.setText(s.driftLngMicro.toString())

        // Interval
        etInterval.setText(s.updateIntervalSec.toString())
    }

    // ── Attach all listeners ──────────────────────────────────────────────────

    private fun attachListeners() = with(binding) {

        // ── Provider toggles
        switchSpoofGps.onChange     { s.spoofGps     = it; warnIfAllOff() }
        switchSpoofNetwork.onChange { s.spoofNetwork = it; warnIfAllOff() }
        switchSpoofPassive.onChange { s.spoofPassive = it }
        switchSpoofBle.onChange     { s.spoofBle     = it }

        // ── Basic jitter
        switchJitter.onChange { s.jitter = it }
        etJitterMax.onDouble  { s.jitterMaxMetres = it }

        // ── Advanced jitter master
        switchAdvancedJitter.onChange { enabled ->
            s.advancedJitter = enabled
            updateAdvancedJitterVisibility(enabled)
            // When turning OFF, reset derived toggles to default so basic mode works cleanly
            if (!enabled) {
                s.jitterStatic          = false
                s.jitterSeparate        = false
                s.jitterPositiveOnlyLat = false
                s.jitterPositiveOnlyLng = false
                s.jitterOnGps           = true
                s.jitterOnNetwork       = true
                s.jitterOnPassive       = false
                // Re-populate those controls so they reflect the reset
                switchJitterStatic.isChecked  = false
                switchJitterSeparate.isChecked = false
                switchPosOnlyLat.isChecked    = false
                switchPosOnlyLng.isChecked    = false
                switchJitterGps.isChecked     = true
                switchJitterNetwork.isChecked = true
                switchJitterPassive.isChecked = false
            }
        }

        // ── Static jitter
        switchJitterStatic.onChange { enabled ->
            s.jitterStatic = enabled
            updateStaticJitterVisibility(enabled)
        }
        etStaticLat.onDouble { s.jitterStaticLat = it }
        etStaticLng.onDouble { s.jitterStaticLng = it }

        // ── Separate axes
        switchJitterSeparate.onChange { enabled ->
            s.jitterSeparate = enabled
            updateSeparateJitterVisibility(enabled)
        }
        etJitterMaxLat.onDouble { s.jitterMaxLat = it.coerceIn(0.1, 50.0) }
        etJitterMaxLng.onDouble { s.jitterMaxLng = it.coerceIn(0.1, 50.0) }

        // ── Positive-only
        switchPosOnlyLat.onChange { s.jitterPositiveOnlyLat = it }
        switchPosOnlyLng.onChange { s.jitterPositiveOnlyLng = it }

        // ── Per-provider jitter
        switchJitterGps.onChange     { s.jitterOnGps     = it }
        switchJitterNetwork.onChange { s.jitterOnNetwork = it }
        switchJitterPassive.onChange { s.jitterOnPassive = it }

        // ── Nudge step
        etNudgeStep.onDouble { if (it > 0) s.nudgeStep = it }
        btn1micro.setOnClickListener   { setNudge(0.000001) }
        btn10micro.setOnClickListener  { setNudge(0.000010) }
        btn100micro.setOnClickListener { setNudge(0.000100) }
        btn1milli.setOnClickListener   { setNudge(0.001000) }

        // ── Drift
        etDriftLat.onLong { s.driftLatMicro = it }
        btnDriftLatMinus.setOnClickListener { stepDriftLat(-1) }
        btnDriftLatPlus.setOnClickListener  { stepDriftLat(+1) }
        btnDriftLatZero.setOnClickListener  { s.driftLatMicro = 0L; etDriftLat.setText("0") }

        etDriftLng.onLong { s.driftLngMicro = it }
        btnDriftLngMinus.setOnClickListener { stepDriftLng(-1) }
        btnDriftLngPlus.setOnClickListener  { stepDriftLng(+1) }
        btnDriftLngZero.setOnClickListener  { s.driftLngMicro = 0L; etDriftLng.setText("0") }

        // ── Interval
        etInterval.onInt { if (it in 1..60) s.updateIntervalSec = it }
        btn1s.setOnClickListener  { setInterval(1)  }
        btn2s.setOnClickListener  { setInterval(2)  }
        btn5s.setOnClickListener  { setInterval(5)  }
        btn10s.setOnClickListener { setInterval(10) }
    }

    // ── Visibility helpers ────────────────────────────────────────────────────

    private fun updateAdvancedJitterVisibility(show: Boolean) {
        binding.layoutAdvancedJitter.visibility = if (show) View.VISIBLE else View.GONE
    }

    private fun updateStaticJitterVisibility(show: Boolean) {
        binding.layoutStaticValues.visibility = if (show) View.VISIBLE else View.GONE
        // When static is on, random options don't apply
        val randomVisible = if (show) View.GONE else View.VISIBLE
        binding.layoutSeparate.visibility    = randomVisible
        binding.layoutPosOnly.visibility     = randomVisible
        binding.layoutProviderJitter.visibility = randomVisible
    }

    private fun updateSeparateJitterVisibility(show: Boolean) {
        binding.layoutSeparateMax.visibility = if (show) View.VISIBLE else View.GONE
    }

    // ── Small helpers ─────────────────────────────────────────────────────────

    private fun setNudge(v: Double)  { s.nudgeStep = v; binding.etNudgeStep.setText(v.toString()) }
    private fun setInterval(v: Int)  { s.updateIntervalSec = v; binding.etInterval.setText(v.toString()) }

    private fun stepDriftLat(d: Long) {
        val n = s.driftLatMicro + d; s.driftLatMicro = n; binding.etDriftLat.setText(n.toString())
    }
    private fun stepDriftLng(d: Long) {
        val n = s.driftLngMicro + d; s.driftLngMicro = n; binding.etDriftLng.setText(n.toString())
    }

    private fun warnIfAllOff() {
        if (!s.spoofGps && !s.spoofNetwork)
            Toast.makeText(this, "⚠️ GPS and Network both off — nothing will be spoofed", Toast.LENGTH_LONG).show()
    }

    // ── Extension helpers for listener boilerplate ────────────────────────────

    private fun com.google.android.material.switchmaterial.SwitchMaterial.onChange(block: (Boolean) -> Unit) {
        setOnCheckedChangeListener { _, v -> block(v) }
    }

    private fun EditText.onDouble(block: (Double) -> Unit) {
        addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { s.toString().toDoubleOrNull()?.let(block) }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
    }

    private fun EditText.onInt(block: (Int) -> Unit) {
        addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { s.toString().toIntOrNull()?.let(block) }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
    }

    private fun EditText.onLong(block: (Long) -> Unit) {
        addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { s.toString().toLongOrNull()?.let(block) }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
