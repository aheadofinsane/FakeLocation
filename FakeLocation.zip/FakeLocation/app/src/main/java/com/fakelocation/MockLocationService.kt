package com.fakelocation

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.location.Location
import android.location.LocationManager
import android.location.provider.ProviderProperties
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

class MockLocationService : Service() {

    inner class LocalBinder : Binder() {
        fun getService(): MockLocationService = this@MockLocationService
    }

    private val binder = LocalBinder()
    private lateinit var locationManager: LocationManager
    lateinit var appSettings: AppSettings private set
    private lateinit var bleBeaconManager: BleBeaconManager
    private val mainHandler = Handler(Looper.getMainLooper())

    private var mockJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO)

    @Volatile var currentLat = 0.0
    @Volatile var currentLng = 0.0
    @Volatile private var speed = 0f

    var onLocationTick: ((lat: Double, lng: Double) -> Unit)? = null

    private val registeredProviders = mutableSetOf<String>()

    companion object {
        const val EXTRA_LAT   = "lat"
        const val EXTRA_LNG   = "lng"
        const val EXTRA_SPEED = "speed"
        private const val NOTIFICATION_ID = 42
        private const val CHANNEL_ID      = "mock_location_channel"
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        locationManager  = getSystemService(LOCATION_SERVICE) as LocationManager
        appSettings      = AppSettings(this)
        bleBeaconManager = BleBeaconManager(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        currentLat = intent?.getDoubleExtra(EXTRA_LAT, 0.0) ?: 0.0
        currentLng = intent?.getDoubleExtra(EXTRA_LNG, 0.0) ?: 0.0
        speed      = intent?.getFloatExtra(EXTRA_SPEED, 0f) ?: 0f
        startForeground(NOTIFICATION_ID, buildNotification())
        syncProviders()
        startLoop()
        return START_STICKY
    }

    override fun onBind(intent: Intent): IBinder = binder

    override fun onDestroy() {
        mockJob?.cancel()
        removeMockProviders(registeredProviders.toList())
        bleBeaconManager.stop()
        super.onDestroy()
    }

    // ── Public API ────────────────────────────────────────────────────────────

    fun updateLocation(lat: Double, lng: Double) {
        currentLat = lat; currentLng = lng
        if (appSettings.spoofBle) bleBeaconManager.update(lat, lng)
        updateNotification()
    }

    fun setSpeed(s: Float) { speed = s }

    fun applySettings() {
        syncProviders()
        restartLoop()
        if (appSettings.spoofBle) bleBeaconManager.update(currentLat, currentLng)
        else bleBeaconManager.stop()
        updateNotification()
    }

    // ── Tick loop ─────────────────────────────────────────────────────────────

    private fun startLoop() {
        mockJob = scope.launch {
            while (isActive) {
                tick()
                delay(appSettings.updateIntervalSec * 1000L)
            }
        }
    }

    private fun restartLoop() { mockJob?.cancel(); startLoop() }

    private fun tick() {
        // 1. Apply drift to anchor
        val dLat = appSettings.driftLatDeg
        val dLng = appSettings.driftLngDeg
        if (dLat != 0.0 || dLng != 0.0) {
            currentLat = (currentLat + dLat).coerceIn(-90.0, 90.0)
            currentLng = (currentLng + dLng).coerceIn(-180.0, 180.0)
        }

        // 2. Compute one jitter sample for this tick (re-rolled completely fresh)
        val jitterEnabled = appSettings.jitter
        val jSample: JitterSample = if (jitterEnabled) computeJitter() else JitterSample(0.0, 0.0)

        // 3. Push to each registered provider — only apply jitter if that provider is opted in
        for (provider in registeredProviders.toList()) {
            val applyJ = jitterEnabled && providerWantsJitter(provider)
            val pushLat = currentLat + if (applyJ) jSample.lat else 0.0
            val pushLng = currentLng + if (applyJ) jSample.lng else 0.0
            try {
                locationManager.setTestProviderLocation(provider, buildLocation(provider, pushLat, pushLng))
            } catch (_: Exception) {}
        }

        // 4. Update BLE if drifting
        if (appSettings.spoofBle && (dLat != 0.0 || dLng != 0.0))
            bleBeaconManager.update(currentLat, currentLng)

        // 5. Notify Activity on main thread when anchor actually moved
        if (dLat != 0.0 || dLng != 0.0) {
            val lat = currentLat; val lng = currentLng
            mainHandler.post { onLocationTick?.invoke(lat, lng) }
            updateNotification()
        }
    }

    // ── Jitter computation ────────────────────────────────────────────────────

    private data class JitterSample(val lat: Double, val lng: Double)

    /**
     * Returns the jitter offset for this tick, respecting all settings.
     *
     * BASIC MODE (advancedJitter = false):
     *   Both lat and lng independently get:
     *     - Random direction (positive or negative)
     *     - Random magnitude in [0, randomCeiling] where ceiling ∈ [0, jitterMaxMetres]
     *     - Re-rolled completely on every tick — magnitude AND sign change each time
     *
     * ADVANCED MODE — STATIC:
     *   Returns exactly (jitterStaticLat, jitterStaticLng) every tick. No randomness.
     *
     * ADVANCED MODE — RANDOM SEPARATE (jitterSeparate = true):
     *   Lat and lng each have their own independent max (jitterMaxLat / jitterMaxLng).
     *   positiveOnlyLat / positiveOnlyLng clamp each axis to ≥ 0 if set.
     *
     * ADVANCED MODE — RANDOM UNIFIED (jitterSeparate = false):
     *   Polar approach using jitterMaxMetres, but positiveOnly flags still apply per axis.
     */
    private fun computeJitter(): JitterSample {
        val s = appSettings

        // Static mode — same value every tick
        if (s.advancedJitter && s.jitterStatic) {
            return JitterSample(s.jitterStaticLat, s.jitterStaticLng)
        }

        return if (!s.advancedJitter) {
            // ── BASIC MODE ────────────────────────────────────────────────────
            // Re-roll ceiling independently for lat and lng so they're never correlated
            val maxMetresLat = Random.nextDouble(0.0, s.jitterMaxMetres)
            val maxMetresLng = Random.nextDouble(0.0, s.jitterMaxMetres)
            val radiusLat    = Random.nextDouble(0.0, maxMetresLat)
            val radiusLng    = Random.nextDouble(0.0, maxMetresLng)
            // Random ± sign, freshly drawn each tick
            val signLat = if (Random.nextBoolean()) 1.0 else -1.0
            val signLng = if (Random.nextBoolean()) 1.0 else -1.0
            JitterSample(
                lat = signLat * radiusLat  / AppSettings.METRES_PER_DEG_LAT,
                lng = signLng * radiusLng  / metersPerDegLng()
            )
        } else if (s.jitterSeparate) {
            // ── ADVANCED — SEPARATE AXES ──────────────────────────────────────
            val latOffset = singleAxisJitter(s.jitterMaxLat, s.jitterPositiveOnlyLat, isLat = true)
            val lngOffset = singleAxisJitter(s.jitterMaxLng, s.jitterPositiveOnlyLng, isLat = false)
            JitterSample(latOffset, lngOffset)
        } else {
            // ── ADVANCED — UNIFIED POLAR + per-axis positive clamp ────────────
            val maxM    = Random.nextDouble(0.0, s.jitterMaxMetres)
            val radius  = Random.nextDouble(0.0, maxM)
            val theta   = Random.nextDouble(0.0, 2.0 * Math.PI)
            var jLat = (radius * sin(theta)) / AppSettings.METRES_PER_DEG_LAT
            var jLng = (radius * cos(theta)) / metersPerDegLng()
            if (s.jitterPositiveOnlyLat) jLat = abs(jLat)
            if (s.jitterPositiveOnlyLng) jLng = abs(jLng)
            JitterSample(jLat, jLng)
        }
    }

    /**
     * Jitter for a single axis: random magnitude re-rolled each tick,
     * optionally clamped to positive only.
     */
    private fun singleAxisJitter(maxMetres: Double, positiveOnly: Boolean, isLat: Boolean): Double {
        val ceiling = Random.nextDouble(0.0, maxMetres)    // re-rolled max each tick
        val radius  = Random.nextDouble(0.0, ceiling)      // actual magnitude
        val sign    = if (positiveOnly) 1.0 else if (Random.nextBoolean()) 1.0 else -1.0
        val mpd     = if (isLat) AppSettings.METRES_PER_DEG_LAT else metersPerDegLng()
        return sign * radius / mpd
    }

    /** Metres per degree longitude at the current latitude. */
    private fun metersPerDegLng(): Double {
        val mpd = AppSettings.METRES_PER_DEG_LAT * cos(Math.toRadians(currentLat))
        return if (mpd > 1.0) mpd else AppSettings.METRES_PER_DEG_LAT
    }

    /** Whether a given provider should receive jitter offsets this tick. */
    private fun providerWantsJitter(provider: String): Boolean {
        if (!appSettings.advancedJitter) return true  // basic mode: always apply to all
        return when (provider) {
            LocationManager.GPS_PROVIDER     -> appSettings.jitterOnGps
            LocationManager.NETWORK_PROVIDER -> appSettings.jitterOnNetwork
            LocationManager.PASSIVE_PROVIDER -> appSettings.jitterOnPassive
            else -> true
        }
    }

    // ── Provider management ───────────────────────────────────────────────────

    private fun syncProviders() {
        val desired = mutableSetOf<String>().apply {
            if (appSettings.spoofGps)     add(LocationManager.GPS_PROVIDER)
            if (appSettings.spoofNetwork) add(LocationManager.NETWORK_PROVIDER)
            if (appSettings.spoofPassive) add(LocationManager.PASSIVE_PROVIDER)
        }
        removeMockProviders((registeredProviders - desired).toList())
        addMockProviders((desired - registeredProviders).toList())
        if (appSettings.spoofBle) bleBeaconManager.update(currentLat, currentLng)
        else bleBeaconManager.stop()
    }

    private fun addMockProviders(providers: List<String>) {
        for (p in providers) {
            try { locationManager.removeTestProvider(p) } catch (_: Exception) {}
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    locationManager.addTestProvider(p, false,
                        p == LocationManager.GPS_PROVIDER, p == LocationManager.NETWORK_PROVIDER,
                        false, true, true, true,
                        ProviderProperties.POWER_USAGE_LOW,
                        if (p == LocationManager.GPS_PROVIDER) ProviderProperties.ACCURACY_FINE
                        else ProviderProperties.ACCURACY_COARSE)
                } else {
                    @Suppress("DEPRECATION")
                    locationManager.addTestProvider(p, false,
                        p == LocationManager.GPS_PROVIDER, p == LocationManager.NETWORK_PROVIDER,
                        false, true, true, true,
                        android.location.Criteria.POWER_LOW,
                        if (p == LocationManager.GPS_PROVIDER) android.location.Criteria.ACCURACY_FINE
                        else android.location.Criteria.ACCURACY_COARSE)
                }
                locationManager.setTestProviderEnabled(p, true)
                registeredProviders += p
            } catch (e: Exception) { e.printStackTrace() }
        }
    }

    private fun removeMockProviders(providers: List<String>) {
        for (p in providers) {
            try { locationManager.setTestProviderEnabled(p, false); locationManager.removeTestProvider(p) } catch (_: Exception) {}
            registeredProviders -= p
        }
    }

    private fun buildLocation(provider: String, lat: Double, lng: Double): Location =
        Location(provider).apply {
            latitude = lat; longitude = lng; altitude = 10.0
            accuracy = if (provider == LocationManager.GPS_PROVIDER) 3.0f else 50.0f
            this.speed = this@MockLocationService.speed
            bearing = 0f; time = System.currentTimeMillis()
            elapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                verticalAccuracyMeters = 5.0f; speedAccuracyMetersPerSecond = 0.5f; bearingAccuracyDegrees = 1.0f
            }
        }

    // ── Notification ──────────────────────────────────────────────────────────

    private fun createNotificationChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "Mock Location", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun buildNotification(): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val prov = registeredProviders.joinToString("·") {
            when (it) { LocationManager.GPS_PROVIDER -> "GPS"; LocationManager.NETWORK_PROVIDER -> "NET"; else -> "PASS" }
        }.ifEmpty { "—" }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("FakeLocation [$prov]  •  ${appSettings.updateIntervalSec}s")
            .setContentText("📍 %.6f, %.6f".format(currentLat, currentLng))
            .setContentIntent(pi).setOngoing(true).build()
    }

    fun updateNotification() {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification())
    }
}
