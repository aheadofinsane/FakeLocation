package com.fakelocation

import android.content.Context
import android.content.SharedPreferences

class AppSettings(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("fakelocation_prefs", Context.MODE_PRIVATE)

    // ── Spoofing toggles ──────────────────────────────────────────────────────
    var spoofGps:     Boolean get() = prefs.getBoolean(KEY_SPOOF_GPS, true)     set(v) = put(KEY_SPOOF_GPS, v)
    var spoofNetwork: Boolean get() = prefs.getBoolean(KEY_SPOOF_NETWORK, true) set(v) = put(KEY_SPOOF_NETWORK, v)
    var spoofPassive: Boolean get() = prefs.getBoolean(KEY_SPOOF_PASSIVE, true) set(v) = put(KEY_SPOOF_PASSIVE, v)
    var spoofBle:     Boolean get() = prefs.getBoolean(KEY_SPOOF_BLE, false)    set(v) = put(KEY_SPOOF_BLE, v)

    // ── Nudge ─────────────────────────────────────────────────────────────────
    var nudgeStep: Double
        get() = prefs.getString(KEY_NUDGE_STEP, "0.000001")!!.toDoubleOrNull() ?: 0.000001
        set(v) = prefs.edit().putString(KEY_NUDGE_STEP, v.toString()).apply()

    // ── Auto-drift ────────────────────────────────────────────────────────────
    var driftLatMicro: Long get() = prefs.getLong(KEY_DRIFT_LAT, 0L) set(v) = put(KEY_DRIFT_LAT, v)
    var driftLngMicro: Long get() = prefs.getLong(KEY_DRIFT_LNG, 0L) set(v) = put(KEY_DRIFT_LNG, v)
    val driftLatDeg: Double get() = driftLatMicro * 0.000001
    val driftLngDeg: Double get() = driftLngMicro * 0.000001

    // ── Update interval ───────────────────────────────────────────────────────
    var updateIntervalSec: Int
        get() = prefs.getInt(KEY_INTERVAL, 1).coerceIn(1, 60)
        set(v) = put(KEY_INTERVAL, v.coerceIn(1, 60))

    // ── Basic jitter ──────────────────────────────────────────────────────────
    var jitter: Boolean
        get() = prefs.getBoolean(KEY_JITTER, false)
        set(v) = put(KEY_JITTER, v)

    /** Max jitter radius in metres (basic mode & advanced non-separate mode). */
    var jitterMaxMetres: Double
        get() = prefs.getString(KEY_JITTER_MAX, "5.0")!!.toDoubleOrNull()?.coerceIn(0.1, 50.0) ?: 5.0
        set(v) = prefs.edit().putString(KEY_JITTER_MAX, v.toString()).apply()

    // ── Advanced jitter master toggle ─────────────────────────────────────────
    /**
     * When false: basic mode — both lat and lng get independent random ± offsets
     *             drawn from [0, randomCeiling] where ceiling ∈ [0, jitterMaxMetres].
     * When true:  advanced mode — all the fields below take effect.
     *             Turning this back to false discards no stored values; the basic
     *             mode just ignores them.
     */
    var advancedJitter: Boolean get() = prefs.getBoolean(KEY_ADV_JITTER, false) set(v) = put(KEY_ADV_JITTER, v)

    // ── Advanced: static jitter ───────────────────────────────────────────────
    /** If true, apply a fixed offset every tick instead of a random one. */
    var jitterStatic: Boolean get() = prefs.getBoolean(KEY_JIT_STATIC, false) set(v) = put(KEY_JIT_STATIC, v)

    /** Fixed lat offset in degrees when static mode is on (can be negative). */
    var jitterStaticLat: Double
        get() = prefs.getString(KEY_JIT_STATIC_LAT, "0.000005")!!.toDoubleOrNull() ?: 0.000005
        set(v) = prefs.edit().putString(KEY_JIT_STATIC_LAT, v.toString()).apply()

    /** Fixed lng offset in degrees when static mode is on (can be negative). */
    var jitterStaticLng: Double
        get() = prefs.getString(KEY_JIT_STATIC_LNG, "0.000005")!!.toDoubleOrNull() ?: 0.000005
        set(v) = prefs.edit().putString(KEY_JIT_STATIC_LNG, v.toString()).apply()

    // ── Advanced: separate lat / lng max ─────────────────────────────────────
    /** If true, lat and lng use their own independent max-metre values. */
    var jitterSeparate: Boolean get() = prefs.getBoolean(KEY_JIT_SEPARATE, false) set(v) = put(KEY_JIT_SEPARATE, v)

    var jitterMaxLat: Double
        get() = prefs.getString(KEY_JIT_MAX_LAT, "5.0")!!.toDoubleOrNull()?.coerceIn(0.1, 50.0) ?: 5.0
        set(v) = prefs.edit().putString(KEY_JIT_MAX_LAT, v.toString()).apply()

    var jitterMaxLng: Double
        get() = prefs.getString(KEY_JIT_MAX_LNG, "5.0")!!.toDoubleOrNull()?.coerceIn(0.1, 50.0) ?: 5.0
        set(v) = prefs.edit().putString(KEY_JIT_MAX_LNG, v.toString()).apply()

    // ── Advanced: positive-only per axis ─────────────────────────────────────
    /** Clamp lat jitter to ≥ 0 (northward only). */
    var jitterPositiveOnlyLat: Boolean get() = prefs.getBoolean(KEY_JIT_POS_LAT, false) set(v) = put(KEY_JIT_POS_LAT, v)
    /** Clamp lng jitter to ≥ 0 (eastward only). */
    var jitterPositiveOnlyLng: Boolean get() = prefs.getBoolean(KEY_JIT_POS_LNG, false) set(v) = put(KEY_JIT_POS_LNG, v)

    // ── Advanced: which providers receive jitter ──────────────────────────────
    var jitterOnGps:     Boolean get() = prefs.getBoolean(KEY_JIT_ON_GPS,  true)  set(v) = put(KEY_JIT_ON_GPS,  v)
    var jitterOnNetwork: Boolean get() = prefs.getBoolean(KEY_JIT_ON_NET,  true)  set(v) = put(KEY_JIT_ON_NET,  v)
    var jitterOnPassive: Boolean get() = prefs.getBoolean(KEY_JIT_ON_PASS, false) set(v) = put(KEY_JIT_ON_PASS, v)

    // ── Private helpers ───────────────────────────────────────────────────────
    private fun put(key: String, v: Boolean) = prefs.edit().putBoolean(key, v).apply()
    private fun put(key: String, v: Int)     = prefs.edit().putInt(key, v).apply()
    private fun put(key: String, v: Long)    = prefs.edit().putLong(key, v).apply()

    companion object {
        const val KEY_SPOOF_GPS      = "spoof_gps"
        const val KEY_SPOOF_NETWORK  = "spoof_network"
        const val KEY_SPOOF_PASSIVE  = "spoof_passive"
        const val KEY_SPOOF_BLE      = "spoof_ble"
        const val KEY_NUDGE_STEP     = "nudge_step"
        const val KEY_DRIFT_LAT      = "drift_lat_micro"
        const val KEY_DRIFT_LNG      = "drift_lng_micro"
        const val KEY_INTERVAL       = "update_interval_sec"
        const val KEY_JITTER         = "jitter"
        const val KEY_JITTER_MAX     = "jitter_max_metres"
        // advanced
        const val KEY_ADV_JITTER     = "adv_jitter"
        const val KEY_JIT_STATIC     = "jit_static"
        const val KEY_JIT_STATIC_LAT = "jit_static_lat"
        const val KEY_JIT_STATIC_LNG = "jit_static_lng"
        const val KEY_JIT_SEPARATE   = "jit_separate"
        const val KEY_JIT_MAX_LAT    = "jit_max_lat"
        const val KEY_JIT_MAX_LNG    = "jit_max_lng"
        const val KEY_JIT_POS_LAT    = "jit_pos_lat"
        const val KEY_JIT_POS_LNG    = "jit_pos_lng"
        const val KEY_JIT_ON_GPS     = "jit_on_gps"
        const val KEY_JIT_ON_NET     = "jit_on_network"
        const val KEY_JIT_ON_PASS    = "jit_on_passive"

        const val METRES_PER_DEG_LAT = 111_320.0
    }
}
