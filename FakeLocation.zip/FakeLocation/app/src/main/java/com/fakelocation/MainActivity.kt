package com.fakelocation

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.fakelocation.databinding.ActivityMainBinding
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var map: MapView
    private lateinit var settings: AppSettings
    private var pinMarker: Marker? = null
    private var mockService: MockLocationService? = null
    private var isBound = false
    private var isRunning = false

    private val presets = listOf(
        // Americas
        Preset("New York",          40.7128,  -74.0060),
        Preset("San Francisco",     37.7749, -122.4194),
        Preset("Los Angeles",       34.0522, -118.2437),
        Preset("São Paulo",        -23.5505,  -46.6333),
        Preset("Mexico City",       19.4326,  -99.1332),
        // Europe
        Preset("London",            51.5074,   -0.1278),
        Preset("Paris",             48.8566,    2.3522),
        Preset("Berlin",            52.5200,   13.4050),
        Preset("Bucharest",         44.4268,   26.1025),
        Preset("Rome",              41.9028,   12.4964),
        Preset("Moscow",            55.7558,   37.6173),
        Preset("Oświęcim (Auschwitz)", 50.0343, 19.2057),
        // Middle East & Africa
        Preset("Dubai",             25.2048,   55.2708),
        Preset("Cairo",             30.0444,   31.2357),
        Preset("Nairobi",           -1.2921,   36.8219),
        // Asia-Pacific
        Preset("Tokyo",             35.6762,  139.6503),
        Preset("Beijing",           39.9042,  116.4074),
        Preset("Mumbai",            19.0760,   72.8777),
        Preset("Sydney",           -33.8688,  151.2093),
        Preset("Singapore",          1.3521,  103.8198),
        // DPRK
        Preset("Pyongyang",         39.0392,  125.7625),
        Preset("Pyongsong",         39.2667,  125.8667),
    )

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            val svc = (binder as MockLocationService.LocalBinder).getService()
            mockService = svc
            isBound = true
            // Register drift callback — service calls this on the main thread each tick
            svc.onLocationTick = { lat, lng ->
                updateFields(GeoPoint(lat, lng))
                movePin(GeoPoint(lat, lng), animate = false)
            }
        }
        override fun onServiceDisconnected(name: ComponentName) {
            mockService?.onLocationTick = null
            mockService = null
            isBound = false
        }
    }

    companion object {
        private const val PERM_REQUEST     = 1001
        private const val SETTINGS_REQUEST = 200
        private const val DEFAULT_LAT      = 37.7749
        private const val DEFAULT_LNG      = -122.4194
        private const val DEFAULT_ZOOM     = 13.0
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().apply {
            load(applicationContext, getPreferences(Context.MODE_PRIVATE))
            userAgentValue = packageName
        }
        binding  = ActivityMainBinding.inflate(layoutInflater)
        settings = AppSettings(this)
        setContentView(binding.root)

        setupOsmMap()
        setupPresets()
        setupControls()
        refreshNudgeLabels()
        checkDeveloperOptions()
    }

    override fun onResume() {
        super.onResume()
        map.onResume()
        refreshNudgeLabels()
        refreshProviderBadge()
    }

    override fun onPause()   { super.onPause();  map.onPause()  }
    override fun onDestroy() {
        if (isBound) { unbindService(serviceConnection); isBound = false }
        map.onDetach()
        super.onDestroy()
    }

    // ── Map setup ─────────────────────────────────────────────────────────────

    private fun setupOsmMap() {
        map = binding.osmMap
        map.setTileSource(TileSourceFactory.MAPNIK)
        map.setMultiTouchControls(true)
        // Disable built-in zoom controls — we provide our own +/- FABs
        map.setBuiltInZoomControls(false)
        map.controller.setZoom(DEFAULT_ZOOM)
        map.controller.setCenter(GeoPoint(DEFAULT_LAT, DEFAULT_LNG))

        placePin(GeoPoint(DEFAULT_LAT, DEFAULT_LNG))

        map.overlays.add(0, MapEventsOverlay(object : MapEventsReceiver {
            override fun singleTapConfirmedHelper(p: GeoPoint): Boolean {
                placePin(p); return true
            }
            override fun longPressHelper(p: GeoPoint) = false
        }))
    }

    private fun placePin(point: GeoPoint) {
        pinMarker?.let { map.overlays.remove(it) }
        pinMarker = Marker(map).apply {
            position   = point
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            title      = "Mock Location"
            isDraggable = true
            setOnMarkerDragListener(object : Marker.OnMarkerDragListener {
                override fun onMarkerDrag(m: Marker)      = updateFields(m.position)
                override fun onMarkerDragStart(m: Marker) {}
                override fun onMarkerDragEnd(m: Marker) {
                    updateFields(m.position)
                    mockService?.updateLocation(m.position.latitude, m.position.longitude)
                }
            })
        }
        map.overlays.add(pinMarker)
        map.invalidate()
        updateFields(point)
        if (isRunning) mockService?.updateLocation(point.latitude, point.longitude)
    }

    /** Move pin without recreating it — used for drift updates from service */
    private fun movePin(point: GeoPoint, animate: Boolean) {
        pinMarker?.position = point
        map.invalidate()
        if (animate) map.controller.animateTo(point)
    }

    private fun updateFields(p: GeoPoint) {
        binding.etLatitude.setText("%.6f".format(p.latitude))
        binding.etLongitude.setText("%.6f".format(p.longitude))
    }

    // ── Presets ───────────────────────────────────────────────────────────────

    private fun setupPresets() {
        binding.presetsRecycler.adapter = PresetAdapter(presets) { preset ->
            val pt = GeoPoint(preset.lat, preset.lng)
            placePin(pt)
            map.controller.animateTo(pt)
        }
    }

    // ── Controls ──────────────────────────────────────────────────────────────

    private fun setupControls() {
        // Coord fields
        binding.btnGo.setOnClickListener { applyManualCoords() }
        binding.etLatitude.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_NEXT) false else { applyManualCoords(); true }
        }
        binding.etLongitude.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_DONE) { applyManualCoords(); true } else false
        }

        // Nudge lat
        binding.btnLatPlus.setOnClickListener  { nudgeLat(+settings.nudgeStep) }
        binding.btnLatMinus.setOnClickListener { nudgeLat(-settings.nudgeStep) }
        // Nudge lng
        binding.btnLngPlus.setOnClickListener  { nudgeLng(+settings.nudgeStep) }
        binding.btnLngMinus.setOnClickListener { nudgeLng(-settings.nudgeStep) }

        // Speed slider
        binding.speedSlider.addOnChangeListener { _, value, _ ->
            binding.tvSpeed.text = "Speed: ${value.toInt()} m/s"
            mockService?.setSpeed(value)
        }

        // Map zoom buttons
        binding.fabZoomIn.setOnClickListener  { map.controller.zoomIn()  }
        binding.fabZoomOut.setOnClickListener { map.controller.zoomOut() }

        // Settings FAB
        binding.fabSettings.setOnClickListener {
            startActivityForResult(Intent(this, SettingsActivity::class.java), SETTINGS_REQUEST)
        }

        // Start / Stop
        binding.btnToggle.setOnClickListener {
            if (isRunning) stopMocking() else startMocking()
        }
    }

    private fun nudgeLat(delta: Double) {
        val lat = binding.etLatitude.text.toString().toDoubleOrNull() ?: return
        val lng = binding.etLongitude.text.toString().toDoubleOrNull() ?: 0.0
        val pt  = GeoPoint((lat + delta).coerceIn(-90.0, 90.0), lng)
        placePin(pt)
        map.controller.animateTo(pt)
    }

    private fun nudgeLng(delta: Double) {
        val lat = binding.etLatitude.text.toString().toDoubleOrNull()  ?: 0.0
        val lng = binding.etLongitude.text.toString().toDoubleOrNull() ?: return
        val pt  = GeoPoint(lat, (lng + delta).coerceIn(-180.0, 180.0))
        placePin(pt)
        map.controller.animateTo(pt)
    }

    private fun applyManualCoords() {
        val lat = binding.etLatitude.text.toString().toDoubleOrNull()
        val lng = binding.etLongitude.text.toString().toDoubleOrNull()
        if (lat == null || lng == null || lat !in -90.0..90.0 || lng !in -180.0..180.0) {
            Toast.makeText(this, "Invalid coordinates", Toast.LENGTH_SHORT).show(); return
        }
        val pt = GeoPoint(lat, lng)
        placePin(pt)
        map.controller.animateTo(pt)
    }

    private fun refreshNudgeLabels() {
        val label = "±${settings.nudgeStep}°"
        binding.tvLatNudge.text = label
        binding.tvLngNudge.text = label
    }

    private fun refreshProviderBadge() {
        if (!isRunning) { binding.tvActiveProviders.text = ""; return }
        val parts = mutableListOf<String>().apply {
            if (settings.spoofGps)     add("GPS")
            if (settings.spoofNetwork) add("NET")
            if (settings.spoofPassive) add("PASS")
            if (settings.spoofBle)     add("BLE")
        }
        binding.tvActiveProviders.text = parts.joinToString(" · ")
    }

    // ── Mocking start / stop ──────────────────────────────────────────────────

    private fun startMocking() {
        if (!checkPermissions()) return

        val lat = binding.etLatitude.text.toString().toDoubleOrNull()  ?: DEFAULT_LAT
        val lng = binding.etLongitude.text.toString().toDoubleOrNull() ?: DEFAULT_LNG

        val intent = Intent(this, MockLocationService::class.java).apply {
            putExtra(MockLocationService.EXTRA_LAT,   lat)
            putExtra(MockLocationService.EXTRA_LNG,   lng)
            putExtra(MockLocationService.EXTRA_SPEED, binding.speedSlider.value)
        }
        ContextCompat.startForegroundService(this, intent)
        bindService(intent, serviceConnection, Context.BIND_AUTO_CREATE)

        isRunning = true
        binding.btnToggle.text = "⏹ Stop Mocking"
        binding.btnToggle.setBackgroundColor(getColor(R.color.stop_red))
        binding.statusDot.setBackgroundResource(R.drawable.dot_active)
        binding.tvStatus.text = "Active  •  ${settings.updateIntervalSec}s"
        refreshProviderBadge()
    }

    private fun stopMocking() {
        if (isBound) { unbindService(serviceConnection); isBound = false }
        stopService(Intent(this, MockLocationService::class.java))
        isRunning = false
        binding.btnToggle.text = "▶ Start Mocking"
        binding.btnToggle.setBackgroundColor(getColor(R.color.start_green))
        binding.statusDot.setBackgroundResource(R.drawable.dot_inactive)
        binding.tvStatus.text = "Inactive"
        binding.tvActiveProviders.text = ""
    }

    // ── Settings result ───────────────────────────────────────────────────────

    @Deprecated("Using for result from SettingsActivity")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == SETTINGS_REQUEST) {
            mockService?.applySettings()
            refreshNudgeLabels()
            refreshProviderBadge()
            if (isRunning) binding.tvStatus.text = "Active  •  ${settings.updateIntervalSec}s"
        }
    }

    // ── Permissions ───────────────────────────────────────────────────────────

    private fun checkPermissions(): Boolean {
        val needed = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (settings.spoofBle && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S)
            needed += Manifest.permission.BLUETOOTH_ADVERTISE

        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        return if (missing.isEmpty()) true
        else { ActivityCompat.requestPermissions(this, missing.toTypedArray(), PERM_REQUEST); false }
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<String>, results: IntArray) {
        super.onRequestPermissionsResult(rc, perms, results)
        if (rc == PERM_REQUEST && results.all { it == PackageManager.PERMISSION_GRANTED }) startMocking()
        else Toast.makeText(this, "Required permissions denied", Toast.LENGTH_LONG).show()
    }

    private fun checkDeveloperOptions() {
        val dev = Settings.Global.getInt(contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0)
        if (dev == 0) AlertDialog.Builder(this)
            .setTitle("Developer Options Required")
            .setMessage("1. Settings → About Phone\n2. Tap Build Number 7×\n3. Developer Options → Select mock location app → FakeLocation")
            .setPositiveButton("Open Settings") { _, _ ->
                startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
            }
            .setNegativeButton("Dismiss", null).show()
    }
}
