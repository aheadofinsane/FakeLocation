package com.fakelocation

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.BluetoothLeAdvertiser
import android.content.Context
import android.os.ParcelUuid
import java.nio.ByteBuffer
import java.util.UUID

/**
 * Advertises a BLE proximity beacon at the current fake coordinates.
 *
 * Two formats are broadcast simultaneously:
 *
 *  • iBeacon  — Apple proximity beacon; UUID + major/minor encoded from lat/lng
 *  • Eddystone-URL — Google open beacon; broadcasts a geo: URI with the coordinates
 *
 * Both are standard read-only advertisements — no pairing, no bonding, no data sent
 * to any remote device. This is identical to what a physical shelf beacon does.
 */
class BleBeaconManager(private val context: Context) {

    private var advertiser: BluetoothLeAdvertiser? = null
    private val callbacks = mutableListOf<AdvertiseCallback>()

    companion object {
        // Fixed iBeacon proximity UUID — change to your own for real deployments
        private val IBEACON_UUID: UUID = UUID.fromString("E2C56DB5-DFFB-48D2-B060-D0F5A71096E0")

        // Eddystone service UUID (assigned number)
        private val EDDYSTONE_SERVICE_UUID: ParcelUuid =
            ParcelUuid.fromString("0000FEAA-0000-1000-8000-00805F9B34FB")
    }

    fun start(lat: Double, lng: Double) {
        val btManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val btAdapter = btManager?.adapter ?: return
        if (!btAdapter.isEnabled) return

        advertiser = btAdapter.bluetoothLeAdvertiser ?: return
        stopAll() // clean up any previous run

        advertiseIBeacon(lat, lng)
        advertiseEddystoneUrl(lat, lng)
    }

    fun stop() = stopAll()

    fun update(lat: Double, lng: Double) {
        stop()
        start(lat, lng)
    }

    // ── iBeacon ───────────────────────────────────────────────────────────────

    private fun advertiseIBeacon(lat: Double, lng: Double) {
        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM)
            .setConnectable(false)
            .build()

        // Encode lat/lng into major (lat × 100 mod 65535) / minor (lng × 100 mod 65535)
        val major = (Math.abs(lat) * 100).toInt() % 65535
        val minor = (Math.abs(lng) * 100).toInt() % 65535

        val payload = buildIBeaconPayload(IBEACON_UUID, major, minor, txPower = -59)

        val data = AdvertiseData.Builder()
            .setIncludeDeviceName(false)
            .addManufacturerData(0x004C, payload) // 0x004C = Apple company ID
            .build()

        val cb = object : AdvertiseCallback() {}
        callbacks += cb
        advertiser?.startAdvertising(settings, data, cb)
    }

    private fun buildIBeaconPayload(uuid: UUID, major: Int, minor: Int, txPower: Int): ByteArray {
        val buf = ByteBuffer.allocate(23)
        buf.put(0x02)  // iBeacon subtype
        buf.put(0x15)  // length (21 bytes follow)
        buf.putLong(uuid.mostSignificantBits)
        buf.putLong(uuid.leastSignificantBits)
        buf.putShort(major.toShort())
        buf.putShort(minor.toShort())
        buf.put(txPower.toByte())
        return buf.array()
    }

    // ── Eddystone-URL ─────────────────────────────────────────────────────────

    private fun advertiseEddystoneUrl(lat: Double, lng: Double) {
        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM)
            .setConnectable(false)
            .build()

        // geo: URI — standard for geographic coordinates in beacons
        val url = "geo:%.6f,%.6f".format(lat, lng)
        val urlPayload = buildEddystoneUrlPayload(url, txPower = -20)

        val data = AdvertiseData.Builder()
            .setIncludeDeviceName(false)
            .addServiceUuid(EDDYSTONE_SERVICE_UUID)
            .addServiceData(EDDYSTONE_SERVICE_UUID, urlPayload)
            .build()

        val cb = object : AdvertiseCallback() {}
        callbacks += cb
        advertiser?.startAdvertising(settings, data, cb)
    }

    private fun buildEddystoneUrlPayload(url: String, txPower: Int): ByteArray {
        // Frame type 0x10 = Eddystone-URL
        // URL scheme: 0x03 = "https://" — but geo: has no scheme prefix code,
        // so we use 0x00 (no-op prefix) and encode the full "geo:..." string
        val urlBytes = url.toByteArray(Charsets.US_ASCII)
        val buf = ByteBuffer.allocate(3 + urlBytes.size)
        buf.put(0x10.toByte())  // frame type
        buf.put(txPower.toByte())
        buf.put(0x00.toByte())  // URL scheme (none / encode full string)
        buf.put(urlBytes)
        return buf.array()
    }

    // ─────────────────────────────────────────────────────────────────────────

    private fun stopAll() {
        callbacks.forEach { runCatching { advertiser?.stopAdvertising(it) } }
        callbacks.clear()
    }
}
