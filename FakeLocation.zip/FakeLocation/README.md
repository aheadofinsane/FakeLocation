# FakeLocation v2 — Android Mock GPS App (OpenStreetMap edition)

Spoof GPS **and** network/cell-triangulation location system-wide.  
No Google account or API key needed — map tiles come from OpenStreetMap.

## What's mocked

| Provider | What it affects |
|---|---|
| `GPS_PROVIDER` | Navigation, fine-location requests, satellite fix apps |
| `NETWORK_PROVIDER` | Cell/Wi-Fi triangulation, coarse-location, low-power location |
| `PASSIVE_PROVIDER` | Apps that listen passively to whatever other providers report |

All three are pushed simultaneously at 1 Hz so any app using any location method receives the fake coordinates.

## Features
- 🗺  OpenStreetMap via osmdroid — no API key, no Google dependency
- 📍 Tap map or drag pin to set location
- 🔢 Manual lat/lng input
- 🏃 Speed field (reported alongside coordinates)
- 🌀 GPS jitter — ±0.5 m random noise to pass plausibility checks
- 🔔 Persistent foreground notification

## Setup

### 1. Enable Developer Options on device
1. Settings → About Phone
2. Tap **Build Number** 7 times
3. Developer Options will appear in Settings

### 2. Set FakeLocation as Mock Location App
Developer Options → **Select mock location app** → FakeLocation

### 3. Build
```bash
# Open folder in Android Studio and click Run, OR:
./gradlew installDebug
```
Requirements: Android 8.0+ (API 26+). No Google Play Services needed.

## Project structure
```
app/src/main/java/com/fakelocation/
  MainActivity.kt        — osmdroid map, UI, controls
  MockLocationService.kt — Foreground service: GPS + Network + Passive spoofing
  PresetAdapter.kt       — City quick-select chips

app/src/main/res/
  layout/activity_main.xml
  layout/item_preset.xml
  values/{colors,strings,themes}.xml
  drawable/…
```

## How network triangulation spoofing works

Android's `LocationManager` exposes `NETWORK_PROVIDER` as a separate provider from GPS.
Apps like browsers, weather apps, and anything requesting `ACCESS_COARSE_LOCATION` use this
provider. By calling `addTestProvider(NETWORK_PROVIDER, ...)` and pushing locations to it at
the same rate as GPS, both fine and coarse location consumers receive the fake coordinates.
`PASSIVE_PROVIDER` is also registered; it echoes whatever GPS/Network report, so background
listeners that never directly request a fix are covered too.
